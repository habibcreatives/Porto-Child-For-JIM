// Cart Custom Ajax Call
jQuery(document).ready(function($) {
    function refreshMiniCart() {
        $.ajax({
            url: wc_cart_fragments_params.wc_ajax_url.toString().replace('%%endpoint%%', 'get_refreshed_fragments'),
            type: 'POST',
            success: function(data) {
                if (data && data.fragments) {
                    $.each(data.fragments, function(key, value) {
                        $(key).replaceWith(value);
                    });
                }
            }
        });
    }

    // Trigger refresh when item is removed
    $(document.body).on('click', '.remove', function() {
        setTimeout(function() {
            refreshMiniCart();
        }, 800);
    });

    // Trigger refresh on page load (ensures cart updates when empty)
    refreshMiniCart();
});
